function paginationMiddleware(req, res, next) {
    try {
        const page = req.query.page !== undefined ? parseInt(req.query.page, 10) : 1;
        const size = parseInt(req.query.size, 10) || 3;

        req.pagination = {
            offset: size * (page - 1),
            limit: size,
            page: page
        };

        next();
    } catch (err) {
        next(err);
    }
}

module.exports = paginationMiddleware;
